def convert():
    print("Image is done")
