print("Sub shopping init")
