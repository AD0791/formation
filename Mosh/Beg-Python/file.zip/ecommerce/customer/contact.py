def contact_info():
    print("Customer A")
